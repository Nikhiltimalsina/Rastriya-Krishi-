const PRODUCTS = [
  {
    category: "Fresh Produce",
    icon: "🥬",
    color: "#2d7a3a",
    bg: "#f0faf2",
    items: ["Vegetables", "Fruits", "Herbs & Spices"],
    img: "https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&h=280&fit=crop",
  },
  {
    category: "Agricultural Inputs",
    icon: "🌱",
    color: "#8b6914",
    bg: "#fdf8ec",
    items: ["Seeds", "Fertilizers", "Pesticides", "Machinery"],
    img: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&h=280&fit=crop",
  },
  {
    category: "Value-Added Products",
    icon: "🫙",
    color: "#c0392b",
    bg: "#fdf2f1",
    items: ["Compost Fertilizers", "Mushroom Products", "Pickles"],
    img: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=280&fit=crop",
  },
];

export default function Products() {
  return (
    <section id="products" style={{ padding: "100px 24px", background: "#f8fffe" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <div style={{ color: "#4caf50", fontWeight: 700, fontSize: 13, letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>
            What We Grow
          </div>
          <h2 style={{
            fontSize: 42, fontWeight: 800, color: "#1a3326",
            fontFamily: "'Playfair Display', Georgia, serif",
          }}>
            Our Products
          </h2>
          <p style={{ color: "#666", fontSize: 17, maxWidth: 600, margin: "16px auto 0", lineHeight: 1.7 }}>
            We offer high-quality products across three core categories, all sourced directly from our trusted network of Nepalese farmers.
          </p>
        </div>

        {/* Product Cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 32 }}>
          {PRODUCTS.map((p) => (
            <div
              key={p.category}
              style={{
                background: "#fff", borderRadius: 20, overflow: "hidden",
                boxShadow: "0 8px 32px rgba(0,0,0,0.08)",
                border: `1px solid ${p.bg}`,
                transition: "all 0.3s",
              }}
              onMouseEnter={e => {
                e.currentTarget.style.transform = "translateY(-8px)";
                e.currentTarget.style.boxShadow = "0 24px 60px rgba(0,0,0,0.14)";
              }}
              onMouseLeave={e => {
                e.currentTarget.style.transform = "";
                e.currentTarget.style.boxShadow = "0 8px 32px rgba(0,0,0,0.08)";
              }}
            >
              {/* Card Image */}
              <div style={{ height: 200, overflow: "hidden", position: "relative" }}>
                <img
                  src={p.img}
                  alt={p.category}
                  style={{ width: "100%", height: "100%", objectFit: "cover" }}
                />
                <div style={{
                  position: "absolute", top: 16, left: 16,
                  background: "#fff", borderRadius: 50,
                  width: 44, height: 44,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 22, boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                }}>
                  {p.icon}
                </div>
              </div>

              {/* Card Body */}
              <div style={{ padding: 28 }}>
                <h3 style={{
                  fontSize: 20, fontWeight: 800, color: p.color,
                  marginBottom: 16,
                  fontFamily: "'Playfair Display', Georgia, serif",
                }}>
                  {p.category}
                </h3>
                <ul style={{ listStyle: "none", padding: 0, margin: "0 0 24px" }}>
                  {p.items.map((item) => (
                    <li key={item} style={{
                      padding: "8px 0", borderBottom: "1px solid #f5f5f5",
                      color: "#444", fontSize: 15,
                      display: "flex", alignItems: "center", gap: 8,
                    }}>
                      <span style={{ color: p.color, fontSize: 12 }}>●</span> {item}
                    </li>
                  ))}
                </ul>
                <a href="#" style={{
                  display: "block", textAlign: "center",
                  background: p.bg, color: p.color,
                  padding: "12px", borderRadius: 10,
                  textDecoration: "none", fontWeight: 700, fontSize: 14,
                  border: `2px solid ${p.color}30`,
                }}>
                  View More →
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
import React, { useEffect } from "react";

const styles = `
  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: 'Segoe UI', Arial, sans-serif;
    background: #111;
  }

  .footer-wave {
    display: block;
    width: 100%;
    line-height: 0;
    overflow: hidden;
  }

  .footer-wave svg {
    display: block;
    width: 100%;
  }

  .site-footer {
    background-color: #1c1c1c;
    color: #ffffff;
  }

  .footer-inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 50px 40px 30px;
    display: grid;
    grid-template-columns: 220px 1fr 1fr 1fr;
    gap: 40px;
    align-items: start;
  }

  .footer-logo img {
    width: 170px;
    height: 170px;
    object-fit: contain;
    display: block;
  }

  .footer-col ul {
    list-style: none;
    display: flex;
    flex-direction: column;
    gap: 16px;
  }

  .footer-col ul li a {
    color: #e8963a;
    text-decoration: none;
    font-size: 16px;
    font-weight: 500;
    transition: opacity 0.2s;
  }

  .footer-col ul li a:hover {
    opacity: 0.75;
    text-decoration: underline;
  }

  .footer-social ul {
    list-style: none;
    display: flex;
    flex-direction: column;
    gap: 16px;
  }

  .footer-social ul li a {
    color: #e8963a;
    text-decoration: none;
    font-size: 16px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 10px;
    transition: opacity 0.2s;
  }

  .footer-social ul li a:hover { opacity: 0.75; }

  .social-icon {
    width: 34px;
    height: 34px;
    background: #333;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
  }

  .social-icon svg { fill: #e8963a; }

  .footer-bottom {
    background: #141414;
    border-top: 1px solid #2a2a2a;
    text-align: center;
    padding: 18px 20px;
    font-size: 14px;
    color: rgba(255,255,255,0.6);
  }

  .footer-bottom a {
    color: #e8963a;
    text-decoration: none;
    font-weight: 600;
  }

  .footer-bottom a:hover { text-decoration: underline; }

  @media (max-width: 900px) {
    .footer-inner {
      grid-template-columns: 1fr 1fr;
      gap: 32px;
    }
    .footer-logo { text-align: center; }
    .footer-logo img { margin: 0 auto; }
  }

  @media (max-width: 540px) {
    .footer-inner {
      grid-template-columns: 1fr;
      padding: 36px 24px 24px;
    }
  }
`;

// ── Data ──────────────────────────────────────────────────────────────────────

const navLinks = [
  { label: "Home",     href: "https://rastriyakrishi.com.np/" },
  { label: "About",    href: "https://rastriyakrishi.com.np/about-us/" },
  { label: "FAQs",     href: "https://rastriyakrishi.com.np/faqs/" },
  { label: "Services", href: "https://rastriyakrishi.com.np/services/" },
  { label: "Blogs",    href: "https://rastriyakrishi.com.np/blogs/" },
];

const quickLinks = [
  { label: "Mission & Vision",  href: "https://rastriyakrishi.com.np/about-us/our-mission-vision/" },
  { label: "Objectives",        href: "https://rastriyakrishi.com.np/about-us/objectives/" },
  { label: "Organogram",        href: "https://rastriyakrishi.com.np/about-us/organogram/" },
  { label: "Board of Directors",href: "https://rastriyakrishi.com.np/about-us/board-of-director/" },
  { label: "Management Team",   href: "https://rastriyakrishi.com.np/about-us/management-team/" },
  { label: "Province Leaders",  href: "https://rastriyakrishi.com.np/about-us/province-leaders/" },
];

const resourceLinks = [
  { label: "Fresh Produce",        href: "https://rastriyakrishi.com.np/products/fresh-produce/" },
  { label: "Agricultural Inputs",  href: "https://rastriyakrishi.com.np/products/agricultural-inputs/" },
  { label: "Value-Added Products", href: "https://rastriyakrishi.com.np/products/value-added-products/" },
  { label: "Notices",              href: "https://rastriyakrishi.com.np/notices/" },
  { label: "Career",               href: "https://rastriyakrishi.com.np/career/" },
  { label: "Downloads",            href: "https://rastriyakrishi.com.np/downloads/" },
];

const socialLinks = [
  {
    label: "Facebook",
    href: "https://www.facebook.com/profile.php?id=61564078713356&sk=about",
    external: true,
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="#e8963a">
        <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
      </svg>
    ),
  },
  {
    label: "LinkedIn",
    href: "https://www.linkedin.com/company/rastriya-krishi-company-nepali-limited/",
    external: true,
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="#e8963a">
        <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z" />
        <rect x="2" y="9" width="4" height="12" />
        <circle cx="4" cy="4" r="2" />
      </svg>
    ),
  },
  {
    label: "Email",
    href: "https://rastriyakrishi.com.np/contact/",
    external: false,
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#e8963a" strokeWidth="2">
        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
        <polyline points="22,6 12,13 2,6" />
      </svg>
    ),
  },
];

// ── Sub-components ────────────────────────────────────────────────────────────

const FooterWave = () => (
  <div className="footer-wave">
    <svg
      viewBox="0 0 1440 80"
      xmlns="http://www.w3.org/2000/svg"
      preserveAspectRatio="none"
    >
      <path d="M0,0 C360,80 1080,80 1440,0 L1440,0 L0,0 Z" fill="#2e7d32" />
      <path
        d="M0,20 C360,90 1080,90 1440,20 L1440,0 C1080,80 360,80 0,0 Z"
        fill="#1b5e20"
      />
    </svg>
  </div>
);

const FooterLogo = () => (
  <div className="footer-logo">
    <a href="https://rastriyakrishi.com.np">
      <img
        src="https://rastriyakrishi.com.np/wp-content/uploads/2024/07/Krishi_Logo-Tr.png"
        alt="Rastriya Krishi Company Nepal Limited"
      />
    </a>
  </div>
);

const FooterLinkColumn = ({ links }) => (
  <div className="footer-col">
    <ul>
      {links.map(({ label, href }) => (
        <li key={label}>
          <a href={href}>{label}</a>
        </li>
      ))}
    </ul>
  </div>
);

const FooterSocial = ({ links }) => (
  <div className="footer-social">
    <ul>
      {links.map(({ label, href, external, icon }) => (
        <li key={label}>
          <a
            href={href}
            {...(external
              ? { target: "_blank", rel: "noopener noreferrer" }
              : {})}
          >
            <span className="social-icon" aria-hidden="true">
              {icon}
            </span>
            {label}
          </a>
        </li>
      ))}
    </ul>
  </div>
);

const FooterBottom = ({ year }) => (
  <div className="footer-bottom">
    Rastriya Krishi Company Nepal Limited &copy; {year} All rights reserved. |
    Crafted by{" "}
    <a href="https://ppsoft.com.np" target="_blank" rel="noopener noreferrer">
      PP<span style={{ fontStyle: "italic" }}>soft</span>
    </a>
    .
  </div>
);

// ── Main Component ────────────────────────────────────────────────────────────

const RastriyaKrishiFooter = () => {
  const year = new Date().getFullYear();

  useEffect(() => {
    // Inject global styles once
    if (!document.getElementById("rk-footer-styles")) {
      const styleTag = document.createElement("style");
      styleTag.id = "rk-footer-styles";
      styleTag.textContent = styles;
      document.head.appendChild(styleTag);
    }
  }, []);

  return (
    <>
      <FooterWave />
      <footer className="site-footer" role="contentinfo">
        <div className="footer-inner">
          <FooterLogo />
          <FooterLinkColumn links={navLinks} />
          <FooterLinkColumn links={quickLinks} />
          <FooterLinkColumn links={resourceLinks} />
          <FooterSocial links={socialLinks} />
        </div>
        <FooterBottom year={year} />
      </footer>
    </>
  );
};

export default RastriyaKrishiFooter;
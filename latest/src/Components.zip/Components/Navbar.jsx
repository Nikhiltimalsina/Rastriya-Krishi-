import { useState, useEffect } from "react";

const NAV_LINKS = [
  {
    label: "About Us",
    sub: ["We, Our Mission & Vision", "Objectives", "Organogram", "Board of Director", "Management Team", "Province Leaders"],
  },
  { label: "Services" },
  {
    label: "Products",
    sub: ["Fresh Produce", "Agricultural Inputs", "Value-Added Products"],
  },
  {
    label: "Groups of Companies",
    sub: ["Parent Company", "Associate Company", "Subsidiary Companies", "Investor Company"],
  },
  { label: "Contact" },
  {
    label: "Resources",
    sub: ["Blogs", "Farmers Empowerment Program", "CSR Activities", "Training Activities", "Notices", "Career", "Grievance", "Downloads"],
  },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      {/* Top Bar */}
      <div style={{ background: "#1a4d2e", color: "#d4edda", fontSize: "13px", padding: "6px 0" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", gap: 24 }}>
            <span>📞 <a href="tel:015922911" style={{ color: "#d4edda", textDecoration: "none" }}>01-5922911</a></span>
            <span>✉️ <a href="mailto:info@rastriyakrishi.com.np" style={{ color: "#d4edda", textDecoration: "none" }}>info@rastriyakrishi.com.np</a></span>
          </div>
          <div style={{ display: "flex", gap: 16 }}>
            <a href="https://www.facebook.com/profile.php?id=61564078713356" target="_blank" rel="noreferrer" style={{ color: "#d4edda", textDecoration: "none" }}>Facebook</a>
            <a href="https://www.linkedin.com/company/rastriya-krishi-company-nepali-limited/" target="_blank" rel="noreferrer" style={{ color: "#d4edda", textDecoration: "none" }}>LinkedIn</a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <nav style={{
        position: "sticky", top: 0, zIndex: 1000,
        background: scrolled ? "rgba(255,255,255,0.97)" : "#fff",
        boxShadow: scrolled ? "0 2px 20px rgba(0,0,0,0.12)" : "0 1px 0 #e8f5e9",
        transition: "all 0.3s ease",
        backdropFilter: "blur(12px)",
      }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 72 }}>
          
          {/* Logo */}
          <a href="/">
            <img
              src="https://rastriyakrishi.com.np/wp-content/uploads/2024/07/Logo_long.jpg"
              alt="Rastriya Krishi"
              style={{ height: 52, objectFit: "contain" }}
            />
          </a>

          {/* Desktop Nav */}
          <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
            {NAV_LINKS.map((link) => (
              <div
                key={link.label}
                style={{ position: "relative" }}
                onMouseEnter={() => setActiveDropdown(link.label)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <button style={{
                  background: "none", border: "none", cursor: "pointer",
                  padding: "8px 14px", fontSize: "14px", fontWeight: 600,
                  color: activeDropdown === link.label ? "#2d7a3a" : "#2c3e50",
                  borderRadius: 6, transition: "all 0.2s",
                  display: "flex", alignItems: "center", gap: 4,
                  fontFamily: "'Merriweather Sans', sans-serif",
                }}>
                  {link.label} {link.sub && <span style={{ fontSize: 10 }}>▼</span>}
                </button>

                {link.sub && activeDropdown === link.label && (
                  <div style={{
                    position: "absolute", top: "100%", left: 0, minWidth: 220,
                    background: "#fff", borderRadius: 10,
                    boxShadow: "0 8px 32px rgba(0,0,0,0.15)",
                    padding: "8px 0", border: "1px solid #e8f5e9", zIndex: 100,
                  }}>
                    {link.sub.map((s) => (
                      <a
                        key={s}
                        href="#"
                        style={{
                          display: "block", padding: "9px 18px", fontSize: 13,
                          color: "#2c3e50", textDecoration: "none", fontWeight: 500,
                          transition: "all 0.15s",
                        }}
                        onMouseEnter={e => { e.target.style.background = "#f0faf2"; e.target.style.color = "#2d7a3a"; e.target.style.paddingLeft = "24px"; }}
                        onMouseLeave={e => { e.target.style.background = ""; e.target.style.color = "#2c3e50"; e.target.style.paddingLeft = "18px"; }}
                      >
                        {s}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          <a href="#shop" style={{
            background: "linear-gradient(135deg, #2d7a3a, #4caf50)",
            color: "#fff", padding: "10px 22px", borderRadius: 8,
            textDecoration: "none", fontWeight: 700, fontSize: 14,
            boxShadow: "0 4px 12px rgba(45,122,58,0.3)",
          }}>
            Shop Now
          </a>
        </div>
      </nav>
    </>
  );
}